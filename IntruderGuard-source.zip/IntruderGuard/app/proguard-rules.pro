# Giữ DeviceAdminReceiver để tránh bị loại nhầm khi shrink bản release.
-keep class com.intruderguard.app.detection.AdminReceiver { *; }
