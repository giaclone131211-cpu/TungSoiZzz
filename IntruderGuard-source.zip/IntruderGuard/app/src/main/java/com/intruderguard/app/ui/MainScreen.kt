package com.intruderguard.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.intruderguard.app.R
import com.intruderguard.app.storage.EventEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Neon = Color(0xFF39FF14)
private val Black = Color(0xFF000000)
private val Red = Color(0xFFFF3B30)
private val Orange = Color(0xFFFF9500)

@Composable
fun MainScreen(vm: MainViewModel) {
    val admin by vm.adminActive.collectAsState()
    val camera by vm.cameraGranted.collectAsState()
    val notification by vm.notificationGranted.collectAsState()
    val events by vm.events.collectAsState()
    val diag by vm.diagLines.collectAsState()
    var guardOn by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon,
        background = Black,
        surface = Color(0xFF101010),
        onPrimary = Black,
        onBackground = Color.White,
        onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Black).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Neon
            )
            Text(
                text = if (guardOn) stringResource(R.string.guard_active_label)
                else stringResource(R.string.guard_inactive_label),
                color = if (guardOn) Neon else Orange,
                fontSize = 14.sp
            )

            if (!admin) StatusButton(stringResource(R.string.status_admin_missing), vm.requestAdmin, Red)
            if (!camera) StatusButton(stringResource(R.string.status_camera_missing), vm.requestCamera, Orange)
            if (!notification) {
                StatusButton(
                    stringResource(R.string.status_notification_missing),
                    vm.requestNotifications,
                    Orange
                )
            }

            Button(
                onClick = {
                    if (guardOn) {
                        vm.stopGuard()
                        guardOn = false
                    } else if (admin && camera) {
                        vm.startGuard()
                        guardOn = true
                    }
                },
                enabled = admin && camera,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (guardOn) Color(0xFF202020) else Neon,
                    disabledContainerColor = Color(0xFF252525)
                )
            ) {
                Text(
                    if (guardOn) stringResource(R.string.btn_stop) else stringResource(R.string.btn_start),
                    color = if (guardOn) Neon else Black
                )
            }

            Text(
                text = stringResource(R.string.not_encrypted_note),
                color = Orange,
                style = MaterialTheme.typography.bodySmall
            )

            Text("${stringResource(R.string.event_log_title)} (${events.size})", color = Neon,
                style = MaterialTheme.typography.titleMedium)
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(events, key = { it.id }) { event ->
                    EventRow(event, onDelete = { vm.deleteEvent(event.id) })
                }
            }

            Text(stringResource(R.string.diagnostics_title), color = Neon,
                style = MaterialTheme.typography.titleMedium)
            LazyColumn(modifier = Modifier.height(150.dp)) {
                items(diag.asReversed()) { line ->
                    Text(line, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun StatusButton(text: String, onClick: () -> Unit, color: Color) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(text, color = color)
    }
}

@Composable
private fun EventRow(event: EventEntity, onDelete: () -> Unit) {
    val time = remember(event.timestamp) {
        SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault()).format(Date(event.timestamp))
    }
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (event.failedAttemptNo >= 0) "Lần nhập sai thứ ${event.failedAttemptNo}"
                    else "Lần nhập sai (không đọc được bộ đếm hệ thống)",
                    color = Neon
                )
                Text(
                    text = "$time • Pin ${event.batteryPercent}%",
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodySmall
                )
                if (!event.photoPath.isNullOrBlank()) {
                    Text("Có tệp ảnh (chưa mã hóa)", color = Orange,
                        style = MaterialTheme.typography.labelSmall)
                }
            }
            TextButton(onClick = onDelete) { Text(stringResource(R.string.delete), color = Color.Gray) }
        }
    }
}
