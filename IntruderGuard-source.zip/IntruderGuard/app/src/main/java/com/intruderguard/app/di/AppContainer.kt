package com.intruderguard.app.di

import android.content.Context
import androidx.room.Room
import com.intruderguard.app.storage.AppDatabase
import com.intruderguard.app.util.DiagLog

/** DI thủ công, nhẹ cho giai đoạn đầu. */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val diagLog = DiagLog(appContext)
    val database: AppDatabase = Room.databaseBuilder(
        appContext,
        AppDatabase::class.java,
        "intruderguard.db"
    ).build()
    val eventDao = database.eventDao()
}
