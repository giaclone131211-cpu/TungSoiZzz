package com.intruderguard.app.storage

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Một sự kiện nhập sai mã khóa màn hình. Ảnh Giai đoạn 1 chưa mã hóa. */
@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val failedAttemptNo: Int,
    val batteryPercent: Int,
    val photoPath: String?,
    val videoPath: String? = null
)
