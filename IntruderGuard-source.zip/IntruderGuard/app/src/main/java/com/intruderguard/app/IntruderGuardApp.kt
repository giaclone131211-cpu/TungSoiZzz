package com.intruderguard.app

import android.app.Application
import com.intruderguard.app.di.AppContainer

class IntruderGuardApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
