package com.intruderguard.app.detection

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import com.intruderguard.app.IntruderGuardApp
import com.intruderguard.app.capture.GuardForegroundService

/** Chỉ đăng ký chính sách watch-login để nhận thông báo nhập sai mã khóa. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) {
        val container = (context.applicationContext as IntruderGuardApp).container
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

        val systemCount = try {
            dpm.currentFailedPasswordAttempts
        } catch (t: Throwable) {
            container.diagLog.logError("Detection", "Không đọc được số lần sai từ DevicePolicyManager", t)
            -1
        }

        container.diagLog.log("Detection", "Nhận onPasswordFailed; số lần hệ thống=$systemCount")
        val serviceIntent = Intent(context, GuardForegroundService::class.java)
            .setAction(GuardForegroundService.ACTION_ATTEMPT_FAILED)
            .putExtra(GuardForegroundService.EXTRA_SYSTEM_ATTEMPTS, systemCount)

        try {
            // Thành công phụ thuộc service bảo vệ đã được bật từ Activity còn hiển thị.
            context.startForegroundService(serviceIntent)
        } catch (t: Throwable) {
            container.diagLog.logError(
                "Detection",
                "Không chuyển được sự kiện tới Foreground Service camera; hãy mở app và bật bảo vệ lại",
                t
            )
        }
    }
}
