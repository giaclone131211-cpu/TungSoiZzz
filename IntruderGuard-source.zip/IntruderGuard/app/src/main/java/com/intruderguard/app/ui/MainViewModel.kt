package com.intruderguard.app.ui

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.intruderguard.app.detection.AdminReceiver
import com.intruderguard.app.di.AppContainer
import com.intruderguard.app.storage.EventEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(private val container: AppContainer) : ViewModel() {
    var requestAdmin: () -> Unit = {}
    var requestCamera: () -> Unit = {}
    var requestNotifications: () -> Unit = {}
    var startGuard: () -> Unit = {}
    var stopGuard: () -> Unit = {}

    private val _adminActive = MutableStateFlow(false)
    val adminActive: StateFlow<Boolean> = _adminActive

    private val _cameraGranted = MutableStateFlow(false)
    val cameraGranted: StateFlow<Boolean> = _cameraGranted

    private val _notificationGranted = MutableStateFlow(false)
    val notificationGranted: StateFlow<Boolean> = _notificationGranted

    val events: StateFlow<List<EventEntity>> = container.eventDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val diagLines = container.diagLog.lines

    fun refresh(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        _adminActive.value = dpm.isAdminActive(ComponentName(context, AdminReceiver::class.java))
        _cameraGranted.value = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        _notificationGranted.value = android.os.Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
    }

    fun deleteEvent(id: Long) {
        viewModelScope.launch {
            try {
                val event = container.eventDao.findById(id)
                container.eventDao.delete(id)
                event?.photoPath?.let { path ->
                    val file = File(path)
                    if (file.exists() && !file.delete()) {
                        container.diagLog.logError("Storage", "Không xóa được ảnh sự kiện đã chọn")
                    }
                }
                container.diagLog.log("Storage", "Đã xóa mục nhật ký id=$id")
            } catch (t: Throwable) {
                container.diagLog.logError("Storage", "Xóa mục nhật ký id=$id thất bại", t)
            }
        }
    }

    fun clearDiag() = container.diagLog.clear()
}
