package com.intruderguard.app.capture

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.intruderguard.app.MainActivity
import com.intruderguard.app.R

/** Sau khi khởi động lại, chỉ thông báo để người dùng tự bật bảo vệ từ Activity. */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(BOOT_CHANNEL, "Khởi động lại", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2001,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, BOOT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(context.getString(R.string.notif_tap_reenable))
            .setContentText("Mở IntruderGuard và nhấn Bật bảo vệ")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        manager.notify(BOOT_NOTIFICATION_ID, notification)
    }

    companion object {
        private const val BOOT_CHANNEL = "boot"
        private const val BOOT_NOTIFICATION_ID = 2001
    }
}
