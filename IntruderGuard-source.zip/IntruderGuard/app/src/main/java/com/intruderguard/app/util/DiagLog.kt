package com.intruderguard.app.util

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Nhật ký nội bộ. Mỗi lỗi cần ghi đúng nguyên nhân, không báo thành công giả. */
class DiagLog(context: Context) {
    private val file = File(context.filesDir, "diag.log")
    private val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines

    init {
        reload()
    }

    @Synchronized
    private fun reload() {
        _lines.value = try {
            if (file.exists()) file.readLines() else emptyList()
        } catch (t: Throwable) {
            listOf("Không đọc được nhật ký: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    @Synchronized
    fun log(tag: String, message: String) {
        val line = "${formatter.format(Date())} [$tag] $message"
        Log.d("IntruderGuard", line)
        try {
            file.appendText(line + "\n")
            if (file.length() > 512_000L) {
                file.writeText(file.readLines().takeLast(1500).joinToString("\n", postfix = "\n"))
            }
            _lines.value = file.readLines()
        } catch (t: Throwable) {
            Log.e("IntruderGuard", "Không ghi được diag.log", t)
            _lines.value = _lines.value + "$line [KHÔNG GHI ĐƯỢC FILE LOG: ${t.message}]"
        }
    }

    fun logError(tag: String, message: String, throwable: Throwable? = null) {
        val detail = throwable?.let {
            " — ${it.javaClass.simpleName}: ${it.message ?: "không có thông báo"}"
        }.orEmpty()
        log(tag, "LỖI: $message$detail")
    }

    @Synchronized
    fun clear() {
        try {
            if (file.exists() && !file.delete()) {
                logError("DiagLog", "Không xóa được diag.log")
            }
            _lines.value = emptyList()
        } catch (t: Throwable) {
            logError("DiagLog", "Xóa nhật ký thất bại", t)
        }
    }
}
