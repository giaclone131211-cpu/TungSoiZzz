package com.intruderguard.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.intruderguard.app.capture.GuardForegroundService
import com.intruderguard.app.detection.AdminReceiver
import com.intruderguard.app.ui.MainScreen
import com.intruderguard.app.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: MainViewModel

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refresh(this) }

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refresh(this)
        if (granted) requestNotificationIfNeeded()
    }

    private val adminEnable = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refresh(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Chặn screenshot của cửa sổ ứng dụng; không phải mã hóa dữ liệu đã lưu.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        val container = (application as IntruderGuardApp).container
        viewModel = MainViewModel(container)
        viewModel.requestAdmin = {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            adminEnable.launch(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(
                    DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                    ComponentName(this@MainActivity, AdminReceiver::class.java)
                )
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "IntruderGuard cần nhận sự kiện nhập sai mã khóa màn hình."
                )
            })
        }
        viewModel.requestCamera = {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
        viewModel.requestNotifications = { requestNotificationIfNeeded() }
        viewModel.startGuard = {
            try {
                GuardForegroundService.start(this)
                container.diagLog.log("UI", "Người dùng yêu cầu bật bảo vệ")
            } catch (t: Throwable) {
                container.diagLog.logError("UI", "Không thể bật Foreground Service camera", t)
            }
        }
        viewModel.stopGuard = {
            try {
                GuardForegroundService.stop(this)
                container.diagLog.log("UI", "Người dùng yêu cầu tắt bảo vệ")
            } catch (t: Throwable) {
                container.diagLog.logError("UI", "Không thể dừng Foreground Service", t)
            }
        }

        setContent { MainScreen(vm = viewModel) }
        viewModel.refresh(this)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            cameraPermission.launch(Manifest.permission.CAMERA)
        } else {
            requestNotificationIfNeeded()
        }
    }

    private fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::viewModel.isInitialized) viewModel.refresh(this)
    }
}
