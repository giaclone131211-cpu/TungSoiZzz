package com.intruderguard.app.capture

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.TotalCaptureResult
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import com.intruderguard.app.util.DiagLog
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Camera2 front-facing still capture. Devices may deny access while locked; no success is faked. */
class FrontCameraCapturer(
    private val context: Context,
    private val diag: DiagLog
) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val captureLock = Semaphore(1)

    fun capturePhoto(): File? {
        if (!captureLock.tryAcquire()) {
            diag.log("Camera", "Bỏ qua lần chụp: đang có một tác vụ camera khác")
            return null
        }
        return try {
            captureInternal()
        } catch (t: Throwable) {
            diag.logError("Camera", "Ngoại lệ khi chụp ảnh", t)
            null
        } finally {
            captureLock.release()
        }
    }

    private fun captureInternal(): File? {
        val cameraId = findFrontCamera() ?: run {
            diag.logError("Camera", "Không tìm thấy camera trước")
            return null
        }
        diag.log("Camera", "Tìm thấy camera trước id=$cameraId; yêu cầu mở camera")

        var camera: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var reader: ImageReader? = null
        var worker: HandlerThread? = null

        try {
            val characteristics = cameraManager.getCameraCharacteristics(cameraId)
            val streamMap = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val availableSizes = streamMap?.getOutputSizes(ImageFormat.JPEG)
            val size = availableSizes
                ?.filter { it.width >= 1280 && it.height >= 720 }
                ?.minByOrNull { it.width.toLong() * it.height.toLong() }
                ?: availableSizes?.minByOrNull { it.width.toLong() * it.height.toLong() }
                ?: Size(1280, 720)

            val activeReader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 3)
            reader = activeReader
            val imageQueue = LinkedBlockingQueue<ByteArray>(3)
            val cameraThread = HandlerThread("intruderguard-camera").also { it.start() }
            worker = cameraThread
            val handler = Handler(cameraThread.looper)
            // Xử lý ImageReader và callback camera trên cùng luồng handler.
            activeReader.setOnImageAvailableListener({ imageReader ->
                try {
                    val image = imageReader.acquireNextImage() ?: return@setOnImageAvailableListener
                    image.use {
                        val buffer = it.planes[0].buffer
                        val bytes = ByteArray(buffer.remaining())
                        buffer.get(bytes)
                        if (!imageQueue.offer(bytes)) {
                            imageQueue.poll()
                            imageQueue.offer(bytes)
                        }
                    }
                } catch (t: Throwable) {
                    diag.logError("Camera", "Đọc dữ liệu JPEG thất bại", t)
                }
            }, handler)

            val opened = Semaphore(0)
            val openError = AtomicReference<String?>(null)
            try {
                cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(device: CameraDevice) {
                        camera = device
                        opened.release()
                    }
                    override fun onDisconnected(device: CameraDevice) {
                        openError.set("Camera bị ngắt kết nối trong lúc mở")
                        device.close()
                        opened.release()
                    }
                    override fun onError(device: CameraDevice, error: Int) {
                        openError.set("CameraDevice.onError code=$error")
                        device.close()
                        opened.release()
                    }
                }, handler)
            } catch (t: Throwable) {
                diag.logError("Camera", "Lệnh openCamera bị từ chối", t)
                return null
            }

            if (!opened.tryAcquire(5, TimeUnit.SECONDS)) {
                diag.logError("Camera", "Hết thời gian chờ mở camera (5 giây)")
                return null
            }
            openError.get()?.let {
                diag.logError("Camera", it)
                return null
            }
            val activeCamera = camera ?: run {
                diag.logError("Camera", "CameraDevice vẫn null sau callback mở")
                return null
            }
            diag.log("Camera", "Mở camera thành công; tạo capture session")

            val sessionReady = Semaphore(0)
            val sessionError = AtomicReference<String?>(null)
            activeCamera.createCaptureSession(
                listOf(activeReader.surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(configured: CameraCaptureSession) {
                        session = configured
                        sessionReady.release()
                    }
                    override fun onConfigureFailed(failed: CameraCaptureSession) {
                        sessionError.set("CameraCaptureSession.onConfigureFailed")
                        sessionReady.release()
                    }
                },
                handler
            )
            if (!sessionReady.tryAcquire(5, TimeUnit.SECONDS)) {
                diag.logError("Camera", "Hết thời gian chờ tạo capture session")
                return null
            }
            sessionError.get()?.let {
                diag.logError("Camera", it)
                return null
            }
            val activeSession = session ?: run {
                diag.logError("Camera", "Capture session null sau khi cấu hình")
                return null
            }

            val request = activeCamera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(activeReader.surface)
                set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                val sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
                set(CaptureRequest.JPEG_ORIENTATION, sensorOrientation)
            }

            // Một khung thử bị loại bỏ để máy ảnh có cơ hội đo sáng, sau đó mới lấy ảnh lưu.
            diag.log("Camera", "Chụp khung đo sáng thử; ảnh thử không được lưu")
            val warmupBytes = captureOne(activeSession, request.build(), handler, imageQueue)
            if (warmupBytes == null) {
                diag.logError("Camera", "Không nhận được khung đo sáng thử")
                return null
            }
            diag.log("Camera", "Khung đo sáng thử nhận được; chụp ảnh sự kiện")
            val jpegBytes = captureOne(activeSession, request.build(), handler, imageQueue)
            if (jpegBytes == null || jpegBytes.isEmpty()) {
                diag.logError("Camera", "Không nhận được dữ liệu JPEG của ảnh sự kiện")
                return null
            }

            val eventDir = File(context.filesDir, "events")
            if (!eventDir.exists() && !eventDir.mkdirs()) {
                diag.logError("Storage", "Không tạo được thư mục riêng events")
                return null
            }
            val output = File(eventDir, "ev_${System.currentTimeMillis()}.jpg")
            try {
                FileOutputStream(output).use { it.write(jpegBytes) }
            } catch (t: Throwable) {
                diag.logError("Storage", "Ghi JPEG vào bộ nhớ riêng thất bại", t)
                output.delete()
                return null
            }
            diag.log(
                "Camera",
                "Ghi ảnh ${output.name} thành công (${jpegBytes.size} bytes). CẢNH BÁO: CHƯA MÃ HÓA."
            )
            return output
        } catch (e: CameraAccessException) {
            diag.logError("Camera", "CameraAccessException: ${e.reason}", e)
            return null
        } finally {
            try { session?.close() } catch (_: Throwable) { }
            try { camera?.close() } catch (_: Throwable) { }
            try { reader?.close() } catch (_: Throwable) { }
            try { worker?.quitSafely() } catch (_: Throwable) { }
        }
    }

    private fun captureOne(
        session: CameraCaptureSession,
        request: CaptureRequest,
        handler: Handler,
        imageQueue: LinkedBlockingQueue<ByteArray>
    ): ByteArray? {
        val captureDone = Semaphore(0)
        val captureError = AtomicReference<String?>(null)
        try {
            session.capture(request, object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    captureDone.release()
                }

                override fun onCaptureFailed(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    failure: CaptureFailure
                ) {
                    captureError.set("onCaptureFailed reason=${failure.reason}")
                    captureDone.release()
                }
            }, handler)
        } catch (t: Throwable) {
            diag.logError("Camera", "Gửi yêu cầu capture thất bại", t)
            return null
        }
        if (!captureDone.tryAcquire(5, TimeUnit.SECONDS)) {
            diag.logError("Camera", "Hết thời gian chờ capture hoàn tất (5 giây)")
            return null
        }
        captureError.get()?.let {
            diag.logError("Camera", it)
            return null
        }
        return imageQueue.poll(5, TimeUnit.SECONDS).also { image ->
            if (image == null) diag.logError("Camera", "Hết thời gian chờ ImageReader trả JPEG (5 giây)")
        }
    }

    private fun findFrontCamera(): String? = try {
        cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        }
    } catch (t: Throwable) {
        diag.logError("Camera", "Không thể liệt kê camera trên thiết bị", t)
        null
    }
}
