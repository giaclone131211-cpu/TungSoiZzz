package com.intruderguard.app.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import com.intruderguard.app.IntruderGuardApp
import com.intruderguard.app.R
import com.intruderguard.app.storage.EventEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Service do người dùng bật từ Activity đang hiển thị.
 * Android/Samsung vẫn có thể chặn camera khi màn hình khóa; lỗi được ghi rõ trong chẩn đoán.
 */
class GuardForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var capturer: FrontCameraCapturer
    private lateinit var diag: com.intruderguard.app.util.DiagLog
    private lateinit var dao: com.intruderguard.app.storage.EventDao

    override fun onCreate() {
        super.onCreate()
        val container = (application as IntruderGuardApp).container
        diag = container.diagLog
        dao = container.eventDao
        capturer = FrontCameraCapturer(this, diag)
        createChannel()
        startAsForeground()
        diag.log("Service", "Foreground Service khởi tạo; loại camera đã khai báo")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ATTEMPT_FAILED -> {
                val systemCount = intent.getIntExtra(EXTRA_SYSTEM_ATTEMPTS, -1)
                diag.log("Service", "Nhận yêu cầu xử lý nhập sai; số lần hệ thống=$systemCount")
                scope.launch {
                    val battery = batteryPercent()
                    val photoFile = capturer.capturePhoto()
                    if (photoFile != null) {
                        try {
                            dao.insert(
                                EventEntity(
                                    timestamp = System.currentTimeMillis(),
                                    failedAttemptNo = systemCount,
                                    batteryPercent = battery,
                                    photoPath = photoFile.absolutePath
                                )
                            )
                            diag.log(
                                "Storage",
                                "Đã lưu metadata sự kiện; ảnh=${photoFile.name}, pin=$battery%. ẢNH CHƯA MÃ HÓA."
                            )
                        } catch (t: Throwable) {
                            diag.logError("Storage", "Lưu metadata sự kiện thất bại", t)
                        }
                    } else {
                        diag.logError("Service", "Không lưu sự kiện ảnh vì bước chụp ảnh thất bại")
                    }
                }
            }
            null -> diag.log("Service", "Service được khởi động không kèm sự kiện nhập sai")
            else -> diag.log("Service", "Bỏ qua action không được hỗ trợ: ${intent.action}")
        }
        return START_NOT_STICKY
    }

    private fun batteryPercent(): Int = try {
        val manager = getSystemService(BatteryManager::class.java)
        manager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    } catch (t: Throwable) {
        diag.logError("Battery", "Không đọc được phần trăm pin", t)
        -1
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notif_channel_guard),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun startAsForeground() {
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_guard_active))
            .setContentText("Camera có thể bị hệ thống hạn chế khi thiết bị khóa")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        if (::diag.isInitialized) diag.log("Service", "Foreground Service bị hủy")
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ATTEMPT_FAILED = "com.intruderguard.app.action.ATTEMPT_FAILED"
        const val EXTRA_SYSTEM_ATTEMPTS = "system_attempts"
        private const val CHANNEL_ID = "guard"
        private const val NOTIFICATION_ID = 1001

        fun start(context: android.content.Context) {
            context.startForegroundService(Intent(context, GuardForegroundService::class.java))
        }

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, GuardForegroundService::class.java))
        }
    }
}
