# IntruderGuard — Giai đoạn 1

Mã nguồn Android/Kotlin cho ứng dụng thử nghiệm trên Android 14+ (API 34 trở lên), giao diện Jetpack Compose và Room.

## Phạm vi có trong bản này

- Kích hoạt `DeviceAdminReceiver` với chính sách `watch-login`.
- Nhận callback `onPasswordFailed()` và đọc `getCurrentFailedPasswordAttempts()`.
- Service foreground loại `camera`, phải được bật từ Activity khi ứng dụng đang hiển thị.
- Thử chụp JPEG bằng Camera2 camera trước sau khi nhận sự kiện.
- Lưu metadata sự kiện bằng Room và ghi chẩn đoán vào bộ nhớ riêng của ứng dụng.
- Thông báo nhắc người dùng bật bảo vệ lại sau khi khởi động lại máy.
- `FLAG_SECURE`, `allowBackup=false`, không khai báo quyền `INTERNET`.
- GitHub Actions build APK debug không cần Android Studio và không yêu cầu Gradle Wrapper trong repo.

## Cảnh báo quan trọng

**Ảnh ở Giai đoạn 1 chưa được mã hóa.** Ảnh nằm trong `filesDir/events` của ứng dụng; không được lưu trong Thư viện ảnh nhưng vẫn là tệp rõ trong sandbox của app. Chỉ dùng để thử nghiệm trên thiết bị của bạn, không lưu dữ liệu nhạy cảm. Xóa ảnh thử nghiệm sau khi kiểm tra. AES/Tink, Keystore, xác thực giải mã và video thuộc các giai đoạn sau, chưa có ở đây.

Android 14+ áp dụng giới hạn nghiêm ngặt cho foreground service dùng camera và quyền camera trong nền. Bật service khi Activity đang hiển thị không đảm bảo Samsung/One UI cho phép chụp ảnh khi thiết bị đã khóa; chính sách thiết bị, phiên bản OS hoặc camera privacy toggle có thể chặn. Nếu bị chặn, hãy đọc màn Chẩn đoán/Logcat; bản này không giả lập sự kiện chụp thành công.

`DeviceAdminReceiver` chỉ nhận sự kiện khi quản trị thiết bị được người dùng bật và hệ thống gọi callback. Không có API công khai đáng tin cậy để nhận biết trực tiếp mọi lần vân tay thất bại; module Accessibility thử nghiệm chưa được triển khai trong Giai đoạn 1.

## Công cụ build

- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- Android SDK Platform 35
- `minSdk=34`, `targetSdk=35`

## Build bằng GitHub Actions

1. Tạo một repository GitHub và tải toàn bộ nội dung thư mục này lên, giữ nguyên các đường dẫn.
2. Chọn nhánh `main`, sau đó mở tab **Actions**.
3. Workflow **Build IntruderGuard APK** sẽ chạy khi push; cũng có thể chạy thủ công bằng **Run workflow**.
4. Mở lần chạy thành công và tải artifact `IntruderGuard-debug`.
5. Giải nén artifact để lấy `app-debug.apk`.

GitHub Actions build APK debug có chữ ký debug tự động, phù hợp cài thử. Đây không phải bản release đã ký bằng khóa riêng của nhà phát triển.

## Cài và kiểm tra trên máy thử

1. Cài APK do Actions tạo và mở IntruderGuard.
2. Cấp quyền Camera và thông báo nếu được hỏi.
3. Nhấn **Chưa kích hoạt quản trị thiết bị**, chọn IntruderGuard rồi kích hoạt quyền quản trị.
4. Mở lại app, nhấn **Bật bảo vệ** khi Activity đang hiển thị. Kiểm tra thông báo foreground “Đang bảo vệ”.
5. Khóa máy, thử nhập sai mã khóa rồi mở khóa đúng và mở IntruderGuard để kiểm tra nhật ký Chẩn đoán.
6. Nếu không có sự kiện hoặc ảnh, giữ nguyên dòng lỗi đầy đủ từ Chẩn đoán/Logcat để điều tra; không xem việc service khởi chạy là bằng chứng camera đã chụp thành công.

Trên Samsung, có thể cần điều chỉnh giới hạn pin cho mục đích thử nghiệm. Không tắt các tính năng bảo mật hệ thống trừ khi bạn hiểu rõ tác động.

## Cấu trúc

```text
IntruderGuard/
├── .github/workflows/build.yml
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/drawable/ic_launcher.xml
        ├── res/values/{strings.xml,colors.xml}
        ├── res/xml/device_admin.xml
        └── java/com/intruderguard/app/
            ├── IntruderGuardApp.kt
            ├── MainActivity.kt
            ├── capture/{BootCompletedReceiver.kt,FrontCameraCapturer.kt,GuardForegroundService.kt}
            ├── detection/AdminReceiver.kt
            ├── di/AppContainer.kt
            ├── storage/{AppDatabase.kt,EventDao.kt,EventEntity.kt}
            ├── ui/{MainScreen.kt,MainViewModel.kt}
            └── util/DiagLog.kt
```
